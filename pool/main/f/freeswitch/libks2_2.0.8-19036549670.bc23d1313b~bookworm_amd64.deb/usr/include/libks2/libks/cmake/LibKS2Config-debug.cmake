#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debug".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ks2" for configuration "Debug"
set_property(TARGET ks2 APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(ks2 PROPERTIES
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/lib/libks2.so.2"
  IMPORTED_SONAME_DEBUG "libks2.so.2"
  )

list(APPEND _cmake_import_check_targets ks2 )
list(APPEND _cmake_import_check_files_for_ks2 "${_IMPORT_PREFIX}/lib/libks2.so.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
